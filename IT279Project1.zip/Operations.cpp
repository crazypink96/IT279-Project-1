#include "operations.h"


Operations::Operations()
{
	int number = 0; 
	int sum = 0; 
	theStack = stack(); 
	
}


int Operations::add(int number)
{	
	sum = number + number; 
	theStack.push(); 
}

int Operations::subtract(int number)
{
	sum = number-number; 
	theStack.push(); 
	theStack.printStack(); 
}

int Operations::multiply(int number)
{
	sum = number * number; 
	theStack.push(); 
	theStack.printStack(); 
}

int Operations::divide(int number)
{
	sum = number / number; 
	if(sum<0)
	{
		cout<<"-"<<sum<<endl;
	}
	theStack.push(); 
	theStack.printStack(); 
	
}

int Operations::modululus(int number)
{
	sum = number % number
	theStack.push(); 
	theStack.printStack(); 
}

void Operations::clear()
{
	theStack.pop(); 
}

void Operations::undo()
{
	theStack.peek(); 
	theStack.printStack(); 
	theStack = temp; 
	temp = stack(); 
}

void Operations::redo()
{
	theStack = temp; 
	temp = stack(); 	
}

void Operations::quit()
{
	cout<<"Have A Nice Day :)"<<endl; 
}
