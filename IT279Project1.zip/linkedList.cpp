#include "linkedList.h"

LinkedList::LinkedList() {

    head = NULL;

    tail = NULL;

    size = 0;

}



LinkedList::~LinkedList(){

    Node *tmp = head;

    while(tmp) {

        head = tmp->nextNode;

        delete tmp;

        tmp = head;

    }

}



void LinkedList::addToEnd(char value) {

    Node *newNode = new Node();



    if(size==0){

            head = newNode;

            tail = newNode;

    } else {

            tail->nextNode = newNode;

            tail = newNode;

    }

	

    newNode->val = value;

    newNode->nextNode = NULL;

    size++;

}



void LinkedList::printList() {

    Node *ptr = head;

    for(int i = 0; i<this->size; i++){

            cout << ptr->val << " ";

            ptr = ptr->nextNode;

    }

    cout<<endl;

}



LinkedList::Node LinkedList::getTail(){

    return *this->tail;

}



int LinkedList::getSize() {

    return size;

}



char LinkedList::removeTail(){

    Node *prev = NULL;

    Node *curr = head;

    

    while(curr->nextNode != NULL){

        prev = curr;

        curr = curr->nextNode;

    }

    

    char output = tail->val;

    tail = prev;

    prev->nextNode = curr->nextNode;

    curr = curr->nextNode;

    size--;

    return output;

}



char LinkedList::remove(char theChar){

    Node *curr = head;

    Node *prev = NULL;

    

    while(curr != NULL || curr->val != theChar){

        prev = curr;

        curr = curr->nextNode;

        

        if(curr->val == theChar){

            prev->nextNode = curr->nextNode;

            curr = curr->nextNode;

            size--;

            return theChar;

        }

    }

    return theChar;

}














