#include <iostream>
using namespace std; 



int main()
{
	
  operations = Operations(); 
  int number; 
  string character; 


  cout<<"Calculator Operations\n"<<
  "+ for Additon\n"<<"- for Subtraction\n"
  <<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  <<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 

  while(character!='Q')	
	{
  		cout<<"Calculator Operations\n"<<
  		"+ for Additon\n"<<"- for Subtraction\n"
  		<<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  		<<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 
		
		cin>>character>>endl;
		if(character=='+')
		{
			operations.add();
			cout<<"Calculator Operations\n"<<
  		"+ for Additon\n"<<"- for Subtraction\n"
  		<<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  		<<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 
			cin>>character>>endl;
		
		}
		if(character=='-')
		{
			operations.subtract(); 
			cout<<"Calculator Operations\n"<<
  		"+ for Additon\n"<<"- for Subtraction\n"
  		<<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  		<<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 
			cin>>character>>endl;
		
		}
		if(character=='*')
		{
			operations.multiply(); 
			cout<<"Calculator Operations\n"<<
  		"+ for Additon\n"<<"- for Subtraction\n"
  		<<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  		<<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 
			cin>>character>>endl;
		
		}
		if(character=='/')
		{
			operations.divide();
			cout<<"Calculator Operations\n"<<
  		"+ for Additon\n"<<"- for Subtraction\n"
  		<<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  		<<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 
			cin>>character>>endl;
		}
		if(character=='%')
		{
			operations.modulus(); 
			cout<<"Calculator Operations\n"<<
  		"+ for Additon\n"<<"- for Subtraction\n"
  		<<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  		<<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 
			cin>>character>>endl;
		}
		if(character=='C')
		{
			operations.clear(); 
			cout<<"Calculator Operations\n"<<
  		"+ for Additon\n"<<"- for Subtraction\n"
  		<<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  		<<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 
			cin>>character>>endl;
		
		}
		if(characetr=='U'
		{
			operations.undo(); 
			cout<<"Calculator Operations\n"<<
  		"+ for Additon\n"<<"- for Subtraction\n"
  		<<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  		<<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 
			cin>>character>>endl;
		
		}
		if(character=='R')
		{
			operations.redo(); 
			cout<<"Calculator Operations\n"<<
  		"+ for Additon\n"<<"- for Subtraction\n"
  		<<"* for Multiplication\n"<<"/ for Division\n"<<"% for Modulous\n"<<
  		<<"C to Clear\n"<<"U to Undo\n"<<"R to Redo\n"<<"Q to Quit Program"<<endl; 
			cin>>character>>endl;
		}
		if(character=='Q')
		{
			operations.quit(); 
		}
		else
		cout<<"Incorrect character entered. Please re enter your character"<<endl;
		cin>>character>>endl; 
	}

return 0; 
  

}
