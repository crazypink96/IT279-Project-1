#ifndef ADD_LL

#define ADD_LL


#include <cstddef>

#include <iostream>

using namespace std;



class LinkedList {

	

public:

	struct Node {

		char val;

		Node *nextNode;

	};

	

	LinkedList();

        ~LinkedList();

	void addToEnd(char value);

	void printList();

        char remove(char theChar);

        char removeTail();

	Node getTail();

        int getSize();

private:

	Node *head, *tail;

	int size, sum;

	double avg;

};



#endif
