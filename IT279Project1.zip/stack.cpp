#include "stack.h"

using namespace std;



Stack::Stack(){

    theLinkedList = LinkedList();

}



void Stack::push(char theChar){

    theLinkedList.addToEnd(theChar);

};



char Stack::pop(){

    return theLinkedList.removeTail();

}



char Stack::peek(){

    return theLinkedList.getTail().val;

}



int Stack::getSize(){

    return theLinkedList.getSize();

}



void Stack::printStack(){

    theLinkedList.printList();

}
