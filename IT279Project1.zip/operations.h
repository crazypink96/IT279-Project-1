#include <iostream>
#ifndef ADD_OPERATIONS

#define ADD_OPERATIONS

#include "stack.h"

#include <cstddef>

using namespace std; 


class Operations
{
	
	public:  
		int add(int number);
		int subtract(int number); 
		int multiply(int number);
		int divide(int number);
		int modulus(int number); 
		void clear();
		void undo();
		void redo();
		void quit();
	private: 
		int number; 
		int sum; 
		stack theStack;  
};
#endif


