#ifndef ADD_STCK

#define ADD_STCK



#include "linkedList.h"

using namespace std;



class Stack {

public:

    Stack();

    void push(char theChar);

    char pop();

    char peek();

    void printStack();

    int getSize();

	

private:

    int size;

    LinkedList theLinkedList ;

};



#endif
